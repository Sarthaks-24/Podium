a, b = map(int, input().split())
# print the sum
