const [a, b] = require('fs').readFileSync(0, 'utf8').trim().split(' ').map(Number);
// print the sum
